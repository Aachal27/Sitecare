<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Sitecare' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'y4~JyPq{~jU,In`W7SWs43ZrVdXz`7.cZ$+Ut*x![{2?g2^M2ZK2m9!shX!H%%yi' );
define( 'SECURE_AUTH_KEY',  'b!D:N1{WXIKojyvF<q,0`a:GQ^ojC~7Oe+&i$+{H9q,M|4@_t#hAD3~zq*p9Ydx=' );
define( 'LOGGED_IN_KEY',    ',s.rZ/#|> 5 &JwFD?r+RR?tI.#Hn`:xgHM`A-s6Ql_hE2l2/1B1GAx /1VV`0i~' );
define( 'NONCE_KEY',        'bZ!S.`A^L([K8L5[o+VJ`sGqcXQU_15F`:_j>*e;)jT^Z({-i@y_N~iar%R;4lKT' );
define( 'AUTH_SALT',        'b|Epzlye;+SU3EP>gdMbLqg#>Otf1C6[v.K8#b|;E&etTJ`WaeC2YY{kDD@Sf/Q}' );
define( 'SECURE_AUTH_SALT', '45R(1wBQ=xvI>b1-#WZ5%9fkv9tv}= 3GOA6K[e-Jm__p!YZCVvQmO=ElU R~NWO' );
define( 'LOGGED_IN_SALT',   '*G!?udV$}D<WSsarXEW!##!1BFrnh{I|!/7K:rv>HUmofqy>}86)Pw:Pn{b4&SxJ' );
define( 'NONCE_SALT',       '$t@yh)eyHKMU)R`{oKE|:%9Q%mow>+LGc/(m2gq,: VRd&!R*)E3lbYgAGm-Kgh%' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
